/*
 * This file is part of John the Ripper password cracker,
 * Copyright (c) 2015 by Kai Zhao
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted.
 *
 * There's ABSOLUTELY NO WARRANTY, express or implied.
 */

int fuzz(struct db_main *db);
